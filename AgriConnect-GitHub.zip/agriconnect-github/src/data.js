// ── AgriConnect Mock Database ─────────────────────────────────────────────
// In a real app this would be replaced by REST API / Supabase / Firebase calls.

export const DB = {
  users: [
    {
      id: 1, name: "John Banda", email: "john@farm.zm", password: "pass123",
      role: "customer", avatar: "JB", location: "Lusaka",
      joined: "Jan 2025", phone: "+260 97 123 4567",
    },
    {
      id: 2, name: "Green Valley Farms", email: "gvf@supplier.zm", password: "pass123",
      role: "supplier", avatar: "GV", location: "Chisamba",
      products: ["Maize", "Soybeans", "Groundnuts"],
      joined: "Mar 2024", phone: "+260 96 456 7890",
      verified: true,
    },
    {
      id: 3, name: "Swift Cargo Ltd", email: "swift@transport.zm", password: "pass123",
      role: "transport", avatar: "SC", location: "Kabwe",
      truckType: "3-ton Pickup", plateNo: "ZMB-4521-T",
      available: true, joined: "Jun 2024", phone: "+260 95 789 0123",
    },
  ],

  products: [
    { id:1,  name:"Hybrid Maize Seed (SC403)",       supplierId:2, category:"Seeds",     price:285, unit:"25 kg bag", stock:120, season:"Nov – Jan", predictedAvail:"Oct 2026", predictedPrice:310, demand:"High",   img:"🌽", description:"Top-yielding hybrid maize bred for Zambian conditions. Drought-tolerant with strong stalk." },
    { id:2,  name:"Soybean Seed (Hernon 147)",        supplierId:2, category:"Seeds",     price:320, unit:"25 kg bag", stock:80,  season:"Nov – Dec", predictedAvail:"Oct 2026", predictedPrice:340, demand:"Medium", img:"🫘", description:"High-protein soybean variety with good nodulation. Resistant to common mosaic virus." },
    { id:3,  name:"D-Compound Fertilizer",            supplierId:2, category:"Fertilizer",price:450, unit:"50 kg bag", stock:200, season:"All year",  predictedAvail:"Now",      predictedPrice:470, demand:"High",   img:"🧪", description:"Balanced NPK compound fertilizer for basal application. Promotes strong root development." },
    { id:4,  name:"Urea (Nitrogen Top Dressing)",     supplierId:2, category:"Fertilizer",price:380, unit:"50 kg bag", stock:150, season:"All year",  predictedAvail:"Now",      predictedPrice:395, demand:"Medium", img:"⚗️", description:"High-nitrogen urea (46% N) for top-dressing maize and other cereals 4–6 weeks after planting." },
    { id:5,  name:"Groundnut Seed (Chalimbana)",      supplierId:2, category:"Seeds",     price:220, unit:"20 kg bag", stock:60,  season:"Nov – Dec", predictedAvail:"Sep 2026", predictedPrice:250, demand:"Low",    img:"🥜", description:"Popular Zambian groundnut variety with large pods and good oil content." },
    { id:6,  name:"Tomato Seedlings (Money Maker)",   supplierId:2, category:"Seedlings", price:150, unit:"tray of 50",stock:40,  season:"Apr – Jun", predictedAvail:"Mar 2027", predictedPrice:165, demand:"High",   img:"🍅", description:"Disease-resistant determinate variety. Ideal for dry-season production under irrigation." },
    { id:7,  name:"Cattle Dip (Triatix 300EC)",       supplierId:2, category:"Chemicals", price:180, unit:"1 L bottle",stock:90,  season:"All year",  predictedAvail:"Now",      predictedPrice:190, demand:"Medium", img:"🐄", description:"Broad-spectrum acaricide/insecticide for tick and fly control in livestock." },
    { id:8,  name:"Wheat Seed (Zambezi)",             supplierId:2, category:"Seeds",     price:260, unit:"25 kg bag", stock:45,  season:"May – Jun", predictedAvail:"Apr 2027", predictedPrice:280, demand:"Medium", img:"🌾", description:"Irrigated wheat variety with high yield potential and good bread-making quality." },
  ],

  orders: [
    { id:101, customerId:1, productId:1, qty:4, total:1140, status:"Delivered",  date:"2026-04-12", transportId:3 },
    { id:102, customerId:1, productId:3, qty:2, total:900,  status:"In Transit", date:"2026-05-18", transportId:3 },
    { id:103, customerId:1, productId:5, qty:1, total:220,  status:"Pending",    date:"2026-05-21", transportId:null },
  ],

  deliveries: [
    { id:1, transportId:3, orderId:101, from:"Chisamba", to:"Lusaka",  distance:"110 km", fee:250, status:"Completed",   date:"2026-04-14" },
    { id:2, transportId:3, orderId:102, from:"Chisamba", to:"Lusaka",  distance:"110 km", fee:250, status:"In Progress", date:"2026-05-20" },
    { id:3, transportId:3, orderId:null, from:"Kabwe",    to:"Ndola",  distance:"200 km", fee:400, status:"Completed",   date:"2026-03-05" },
  ],

  cropGuides: [
    {
      name:"Maize", img:"🌽",
      soil:"Loamy, well-drained, pH 5.5–7.0",
      season:"November – January",
      spacing:"75 cm × 25 cm (2 seeds/hole)",
      fertilizer:"D-Compound at planting + Urea top-dressing at 4–6 weeks",
      diseases:"Streak Virus, Stalk Borer, Grey Leaf Spot",
      yield:"4–8 t/ha (irrigated up to 12 t/ha)",
      harvest:"April – May",
      tips:"Plant with first rains. Weed at 2–3 weeks. Apply Urea before tasselling.",
    },
    {
      name:"Soybeans", img:"🫘",
      soil:"Sandy loam, pH 6.0–6.5",
      season:"November – December",
      spacing:"45 cm × 5 cm (single row)",
      fertilizer:"Rhizobium inoculant; low nitrogen, high phosphorus",
      diseases:"Soybean Rust, Bean Mosaic Virus",
      yield:"1.5–3 t/ha",
      harvest:"March – April",
      tips:"Inoculate seed before planting. Rotate with maize. Harvest when 95% of pods turn brown.",
    },
    {
      name:"Groundnuts", img:"🥜",
      soil:"Sandy loam, well-drained, pH 5.8–6.2",
      season:"November – December",
      spacing:"45 cm × 15 cm",
      fertilizer:"Low N; P-rich basal; gypsum at pegging",
      diseases:"Rosette Disease, Leaf Spot, Aflatoxin",
      yield:"0.8–1.5 t/ha",
      harvest:"March – April",
      tips:"Avoid waterlogging. Peg gypsum broadcast at flowering. Dry thoroughly before storage.",
    },
    {
      name:"Tomatoes", img:"🍅",
      soil:"Rich loam, pH 6.0–6.8",
      season:"April – June (dry season, irrigated)",
      spacing:"60 cm × 45 cm (staked)",
      fertilizer:"High K and Ca; avoid excess N after fruiting",
      diseases:"Bacterial Wilt, Late Blight, Tuta absoluta",
      yield:"20–40 t/ha",
      harvest:"July – September",
      tips:"Stake plants at 20 cm height. Drip irrigation preferred. Scout for Tuta absoluta weekly.",
    },
    {
      name:"Cassava", img:"🍠",
      soil:"Sandy loam to loam, tolerates poor soil",
      season:"October – December",
      spacing:"1 m × 1 m",
      fertilizer:"Low input; NPK 10:10:10 optional at planting",
      diseases:"Cassava Mosaic Virus, Brown Streak",
      yield:"15–30 t/ha fresh roots",
      harvest:"12–18 months after planting",
      tips:"Use disease-free cuttings. Mound planting improves drainage. Weed in first 3 months.",
    },
    {
      name:"Wheat", img:"🌾",
      soil:"Heavy loam, pH 6.0–7.0 (irrigated)",
      season:"May – June",
      spacing:"Drill sow at 120 kg/ha",
      fertilizer:"High N (Urea split), P at planting",
      diseases:"Wheat Rust, Septoria Leaf Blotch",
      yield:"4–7 t/ha irrigated",
      harvest:"September – October",
      tips:"Irrigate every 10–14 days. Apply fungicide at flag leaf stage.",
    },
  ],

  weather: {
    temp: 22, humidity: 58, condition: "Partly Cloudy",
    wind: "14 km/h", rainIn: "3 days", location: "Lusaka, Zambia",
    advisory: "Rain expected in 3 days — delay fertilizer top-dressing until after rains clear.",
  },

  forecast: [
    { day:"Today", icon:"⛅", hi:22, lo:15, rain:10 },
    { day:"Thu",   icon:"🌧",  hi:20, lo:14, rain:80 },
    { day:"Fri",   icon:"🌧",  hi:18, lo:13, rain:75 },
    { day:"Sat",   icon:"⛅", hi:21, lo:14, rain:30 },
    { day:"Sun",   icon:"☀️", hi:25, lo:16, rain:5  },
    { day:"Mon",   icon:"☀️", hi:27, lo:17, rain:5  },
    { day:"Tue",   icon:"⛅", hi:24, lo:15, rain:15 },
  ],

  marketPrices: [
    { crop:"Maize",      price:"K850",   unit:"/50 kg", change:"+3.2%", trend:"up"   },
    { crop:"Soybeans",   price:"K1,200", unit:"/50 kg", change:"+1.8%", trend:"up"   },
    { crop:"Groundnuts", price:"K1,800", unit:"/50 kg", change:"-0.5%", trend:"down" },
    { crop:"Wheat",      price:"K920",   unit:"/50 kg", change:"+2.1%", trend:"up"   },
    { crop:"Cassava",    price:"K420",   unit:"/50 kg", change:"0.0%",  trend:"flat" },
    { crop:"Sunflower",  price:"K1,050", unit:"/50 kg", change:"+4.0%", trend:"up"   },
    { crop:"Cotton",     price:"K2,300", unit:"/50 kg", change:"-1.2%", trend:"down" },
    { crop:"Sorghum",    price:"K680",   unit:"/50 kg", change:"+0.9%", trend:"up"   },
  ],

  communityPosts: [
    { id:1, author:"Joseph Mwamba",    role:"customer",  text:"Anyone know a reliable supplier for SC403 seed in the Chisamba area? Season is coming up fast and I need at least 10 bags.", time:"2h ago", likes:5,  replies:3 },
    { id:2, author:"Green Valley Farms",role:"supplier", text:"✅ SC403 Hybrid Maize and Hernon 147 Soybean seed back in stock! Order before end of May for 5% early-bird discount. Call or order online.", time:"5h ago", likes:12, replies:7 },
    { id:3, author:"Dr. Agnes Phiri",  role:"expert",    text:"Reminder: apply D-Compound at planting time and Urea top dressing 4–6 weeks after emergence for best maize yields. Avoid applying fertilizer when rain is forecast within 48h.", time:"1d ago", likes:28, replies:11 },
    { id:4, author:"Michael Tembo",    role:"customer",  text:"The tomato seedlings from GV Farms were excellent quality this season. Germination rate over 90%. Highly recommended 👍", time:"2d ago", likes:19, replies:4 },
    { id:5, author:"Swift Cargo Ltd",  role:"transport", text:"Now serving Lusaka → Chisamba → Kabwe → Ndola route. Reliable cold-chain and dry goods transport. Competitive rates. Contact us for a quote.", time:"3d ago", likes:8, replies:2 },
  ],

  pestAlerts: [
    { crop:"Maize",    pest:"Fall Armyworm",      severity:"High",   region:"Southern & Central", action:"Apply Coragen or Ampligo. Inspect fields at dawn." },
    { crop:"Soybeans", pest:"Bean Soybean Aphid",  severity:"Medium", region:"Eastern Province",    action:"Use imidacloprid spray. Natural predators help — avoid broad-spectrum insecticides." },
    { crop:"Tomatoes", pest:"Tuta absoluta",       severity:"High",   region:"Nationwide",          action:"Use pheromone traps. Apply Spinosad or Coragen weekly." },
  ],
};

export const formatK = (n) => `K${Number(n).toLocaleString()}`;
export const trendColor = (t) => t === "up" ? "#2E7D32" : t === "down" ? "#C62828" : "#888";
export const trendArrow = (t) => t === "up" ? "↑" : t === "down" ? "↓" : "→";
export const demandColor = (d) => d === "High" ? { bg:"#FFEBEE", fg:"#C62828" } : d === "Medium" ? { bg:"#FFF8E1", fg:"#E65100" } : { bg:"#E8F5E9", fg:"#2E7D32" };
export const statusStyle = (s) => {
  if (s === "Delivered" || s === "Completed") return { bg:"#E8F5E9", fg:"#2E7D32" };
  if (s === "In Transit" || s === "In Progress") return { bg:"#E3F2FD", fg:"#1565C0" };
  return { bg:"#FFF8E1", fg:"#F57F17" };
};
