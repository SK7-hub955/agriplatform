import { DB, formatK, trendColor, trendArrow, demandColor } from '../data.js';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';

const CHART_DATA = [
  { month:'Nov', maize:780, soya:1100, gnut:1700 },
  { month:'Dec', maize:800, soya:1140, gnut:1740 },
  { month:'Jan', maize:820, soya:1160, gnut:1780 },
  { month:'Feb', maize:835, soya:1175, gnut:1810 },
  { month:'Mar', maize:842, soya:1188, gnut:1790 },
  { month:'Apr', maize:848, soya:1195, gnut:1800 },
  { month:'May', maize:850, soya:1200, gnut:1800 },
];

export default function MarketPricesPage() {
  return (
    <div className="fade-up">
      <div className="page-header">
        <h1>Live Market Prices 📈</h1>
        <p>Current commodity prices and AI-powered price forecasts for the upcoming season.</p>
      </div>

      {/* Price cards grid */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(220px,1fr))', gap:14, marginBottom:24 }}>
        {DB.marketPrices.map((m,i) => (
          <div key={i} className="card" style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
            <div>
              <div style={{ fontWeight:600, fontSize:15, color:'var(--green-900)' }}>{m.crop}</div>
              <div style={{ fontSize:11, color:'var(--text-muted)', marginTop:2 }}>Zambia national avg</div>
            </div>
            <div style={{ textAlign:'right' }}>
              <div style={{ fontSize:20, fontWeight:700, color:'var(--green-800)', fontFamily:'var(--font-display)' }}>{m.price}</div>
              <div style={{ fontSize:11, color:'var(--text-muted)' }}>{m.unit}</div>
              <div style={{ fontSize:12, color:trendColor(m.trend), fontWeight:600, marginTop:2 }}>{trendArrow(m.trend)} {m.change}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Chart */}
      <div className="card" style={{ marginBottom:24 }}>
        <h3 style={{ fontFamily:'var(--font-display)', fontSize:20, color:'var(--green-900)', marginBottom:6 }}>Price Trends — Season 2025/26 (ZMW / 50 kg)</h3>
        <p style={{ fontSize:13, color:'var(--text-muted)', marginBottom:20 }}>Maize, Soybeans, and Groundnuts weekly averages</p>
        <ResponsiveContainer width="100%" height={240}>
          <BarChart data={CHART_DATA} barGap={2} barCategoryGap="25%">
            <XAxis dataKey="month" tick={{ fontSize:12 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fontSize:11 }} axisLine={false} tickLine={false} tickFormatter={v=>`K${v}`} width={56} />
            <Tooltip formatter={(v,n)=>[`K${v}`,n.charAt(0).toUpperCase()+n.slice(1)]} contentStyle={{ borderRadius:10, border:'1px solid #e0e0e0', fontSize:12 }} />
            <Bar dataKey="maize"  fill="#40916C" radius={[4,4,0,0]} name="Maize" />
            <Bar dataKey="soya"   fill="#52B788" radius={[4,4,0,0]} name="Soybeans" />
            <Bar dataKey="gnut"   fill="#8B6914" radius={[4,4,0,0]} name="Groundnuts" />
          </BarChart>
        </ResponsiveContainer>
        <div style={{ display:'flex', gap:16, marginTop:12, flexWrap:'wrap' }}>
          {[['#40916C','Maize'],['#52B788','Soybeans'],['#8B6914','Groundnuts']].map(([c,l]) => (
            <div key={l} style={{ display:'flex', alignItems:'center', gap:6, fontSize:12, color:'var(--text-muted)' }}>
              <div style={{ width:12, height:12, borderRadius:3, background:c }} />{l}
            </div>
          ))}
        </div>
      </div>

      {/* AI Prediction Table */}
      <div className="card">
        <h3 style={{ fontFamily:'var(--font-display)', fontSize:20, color:'var(--green-900)', marginBottom:4 }}>🤖 AI Price Predictions — Next Season</h3>
        <p style={{ fontSize:13, color:'var(--text-muted)', marginBottom:16 }}>Based on historical POS data, seasonal demand patterns, and planting reports.</p>
        <div style={{ overflowX:'auto' }}>
          <table className="data-table">
            <thead>
              <tr>
                <th>Product</th>
                <th>Current Price</th>
                <th>Predicted Price</th>
                <th>Available From</th>
                <th>Demand</th>
                <th>Buy Advice</th>
              </tr>
            </thead>
            <tbody>
              {DB.products.map(p => {
                const dc = demandColor(p.demand);
                const diff = ((p.predictedPrice - p.price) / p.price * 100).toFixed(1);
                return (
                  <tr key={p.id}>
                    <td><strong>{p.img}</strong> {p.name}</td>
                    <td style={{ fontWeight:600 }}>{formatK(p.price)}</td>
                    <td style={{ fontWeight:700, color:'var(--blue-800)' }}>
                      {formatK(p.predictedPrice)}
                      <span style={{ fontSize:11, color:diff>0?'#C62828':'#2E7D32', marginLeft:6 }}>
                        {diff>0?'▲':'▼'} {Math.abs(diff)}%
                      </span>
                    </td>
                    <td>{p.predictedAvail}</td>
                    <td><span className="badge" style={{ background:dc.bg, color:dc.fg }}>{p.demand}</span></td>
                    <td style={{ fontSize:12, color:'var(--text-secondary)' }}>
                      {p.demand==='High' ? '⚡ Buy early — prices rising' : p.demand==='Medium' ? '⏳ Buy when needed' : '✅ No rush — low demand'}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
