import { useState } from 'react';
import { DB, formatK, demandColor, statusStyle } from '../data.js';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

const SALES_DATA = [
  { month:'Nov', revenue:12400 }, { month:'Dec', revenue:18200 },
  { month:'Jan', revenue:21000 }, { month:'Feb', revenue:17500 },
  { month:'Mar', revenue:14200 }, { month:'Apr', revenue:19800 },
  { month:'May', revenue:16300 },
];

export function SupplierDashboard({ user }) {
  const myProducts = DB.products.filter(p => p.supplierId === user.id);
  const myOrders   = DB.orders.filter(o => myProducts.some(p => p.id === o.productId));
  const revenue    = myOrders.reduce((a,b) => a + b.total, 0);

  return (
    <div className="fade-up">
      <div className="page-header">
        <h1>Supplier Dashboard 🌾</h1>
        <p>Manage your products, track orders, and monitor performance.</p>
      </div>

      <div className="grid-4" style={{ marginBottom:24 }}>
        {[
          { label:'Products Listed', val:myProducts.length, icon:'📦', bg:'#E8F5E9' },
          { label:'Total Revenue',   val:formatK(revenue),  icon:'💰', bg:'#FFF8E1' },
          { label:'Active Orders',   val:myOrders.filter(o=>o.status!=='Delivered').length, icon:'📋', bg:'#E3F2FD' },
          { label:'Avg Rating',      val:'4.8 ★',            icon:'⭐', bg:'#FFF3E0' },
        ].map((s,i) => (
          <div key={i} className="stat-card" style={{ background:s.bg }}>
            <div style={{ fontSize:26, marginBottom:10 }}>{s.icon}</div>
            <div style={{ fontSize:24, fontWeight:700, color:'var(--green-900)', fontFamily:'var(--font-display)' }}>{s.val}</div>
            <div style={{ fontSize:12, color:'var(--text-muted)' }}>{s.label}</div>
          </div>
        ))}
      </div>

      <div className="grid-2">
        <div className="card">
          <h3 style={{ fontFamily:'var(--font-display)', fontSize:20, color:'var(--green-900)', marginBottom:16 }}>Revenue Trend (ZMW)</h3>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={SALES_DATA}>
              <XAxis dataKey="month" tick={{ fontSize:11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize:10 }} axisLine={false} tickLine={false} tickFormatter={v=>`K${(v/1000).toFixed(0)}k`} width={46} />
              <Tooltip formatter={v=>[`K${v.toLocaleString()}`,'Revenue']} contentStyle={{ borderRadius:10, fontSize:12 }} />
              <Line type="monotone" dataKey="revenue" stroke="#40916C" strokeWidth={2.5} dot={{ fill:'#40916C', r:4 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="card">
          <h3 style={{ fontFamily:'var(--font-display)', fontSize:20, color:'var(--green-900)', marginBottom:16 }}>Product Stock Status</h3>
          <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
            {myProducts.map(p => (
              <div key={p.id} style={{ display:'flex', justifyContent:'space-between', alignItems:'center', padding:'10px 12px', background:'#F9FBF7', borderRadius:8 }}>
                <div>
                  <div style={{ fontSize:14, fontWeight:500 }}>{p.img} {p.name}</div>
                  <div style={{ fontSize:11, color:'var(--text-muted)', marginTop:2 }}>{p.category}</div>
                </div>
                <div style={{ textAlign:'right' }}>
                  <div style={{ fontSize:14, fontWeight:700, color: p.stock < 50 ? '#C62828' : 'var(--green-800)' }}>{p.stock} units</div>
                  <div style={{ fontSize:11, color:'var(--text-muted)' }}>{formatK(p.price)}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export function SupplierInventory({ user }) {
  const myProducts = DB.products.filter(p => p.supplierId === user.id);
  const [form, setForm] = useState({ name:'', category:'Seeds', price:'', unit:'', stock:'', season:'' });
  const [added, setAdded] = useState(false);
  const [errors, setErrors] = useState({});

  const validate = () => {
    const e = {};
    if (!form.name.trim())  e.name  = 'Required';
    if (!form.price)        e.price = 'Required';
    if (!form.unit.trim())  e.unit  = 'Required';
    if (!form.stock)        e.stock = 'Required';
    return e;
  };

  const submit = () => {
    const e = validate();
    if (Object.keys(e).length) { setErrors(e); return; }
    DB.products.push({
      id: Date.now(),
      ...form, price: +form.price, stock: +form.stock,
      supplierId: user.id,
      predictedAvail: 'TBD', predictedPrice: Math.round(+form.price * 1.05),
      demand: 'Medium', img: '📦', description: '',
    });
    setAdded(true);
    setForm({ name:'', category:'Seeds', price:'', unit:'', stock:'', season:'' });
    setErrors({});
    setTimeout(() => setAdded(false), 3000);
  };

  return (
    <div className="fade-up">
      <div className="page-header">
        <h1>Inventory Management 📦</h1>
        <p>View and update your product listings.</p>
      </div>

      {added && <div className="alert-success">✅ Product added successfully and is now visible in the Marketplace!</div>}

      <div style={{ display:'grid', gridTemplateColumns:'1fr 320px', gap:20, alignItems:'start' }}>
        <div className="card">
          <h3 style={{ fontFamily:'var(--font-display)', fontSize:20, color:'var(--green-900)', marginBottom:16 }}>Current Listings</h3>
          <div style={{ overflowX:'auto' }}>
            <table className="data-table">
              <thead>
                <tr><th>Product</th><th>Price</th><th>Stock</th><th>Season</th><th>Demand</th><th>Pred. Price</th></tr>
              </thead>
              <tbody>
                {myProducts.map(p => {
                  const dc = demandColor(p.demand);
                  return (
                    <tr key={p.id}>
                      <td><strong>{p.img}</strong> {p.name}</td>
                      <td style={{ fontWeight:600 }}>{formatK(p.price)}</td>
                      <td style={{ color: p.stock < 50 ? '#C62828' : 'var(--green-800)', fontWeight:600 }}>{p.stock}</td>
                      <td>{p.season}</td>
                      <td><span className="badge" style={{ background:dc.bg, color:dc.fg }}>{p.demand}</span></td>
                      <td style={{ color:'var(--blue-800)', fontWeight:600 }}>{formatK(p.predictedPrice)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        <div className="card" style={{ background:'#F9FBF7' }}>
          <h3 style={{ fontFamily:'var(--font-display)', fontSize:20, color:'var(--green-900)', marginBottom:16 }}>Add New Product</h3>
          <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
            {[
              { key:'name', placeholder:'Product name *', type:'text' },
              { key:'price', placeholder:'Price (ZMW) *', type:'number' },
              { key:'unit', placeholder:'Unit (e.g. 50 kg bag) *', type:'text' },
              { key:'stock', placeholder:'Stock quantity *', type:'number' },
              { key:'season', placeholder:'Season (e.g. Nov–Jan)', type:'text' },
            ].map(f => (
              <div key={f.key}>
                <input type={f.type} placeholder={f.placeholder}
                  value={form[f.key]} onChange={e => setForm(p=>({...p,[f.key]:e.target.value}))}
                  style={{ borderColor: errors[f.key] ? '#C62828' : undefined }} />
                {errors[f.key] && <div style={{ color:'#C62828', fontSize:11, marginTop:3 }}>{errors[f.key]}</div>}
              </div>
            ))}
            <select value={form.category} onChange={e=>setForm(p=>({...p,category:e.target.value}))}>
              {['Seeds','Fertilizer','Seedlings','Chemicals','Equipment','Produce'].map(c=><option key={c}>{c}</option>)}
            </select>
            <button className="btn-primary" onClick={submit}>➕ Add to Marketplace</button>
          </div>
        </div>
      </div>
    </div>
  );
}

export function SupplierOrders({ user }) {
  const myProducts = DB.products.filter(p => p.supplierId === user.id);
  const myOrders   = DB.orders.filter(o => myProducts.some(p => p.id === o.productId));

  return (
    <div className="fade-up">
      <div className="page-header">
        <h1>Incoming Orders 📋</h1>
        <p>Track all customer orders for your products.</p>
      </div>

      <div className="grid-3" style={{ marginBottom:24 }}>
        {[
          { label:'Total Orders',    val:myOrders.length,                                           icon:'📦', bg:'#E8F5E9' },
          { label:'Pending',         val:myOrders.filter(o=>o.status==='Pending').length,            icon:'⏳', bg:'#FFF8E1' },
          { label:'In Transit',      val:myOrders.filter(o=>o.status==='In Transit').length,         icon:'🚚', bg:'#E3F2FD' },
        ].map((s,i) => (
          <div key={i} className="stat-card" style={{ background:s.bg }}>
            <div style={{ fontSize:22, marginBottom:8 }}>{s.icon}</div>
            <div style={{ fontSize:22, fontWeight:700, color:'var(--green-900)', fontFamily:'var(--font-display)' }}>{s.val}</div>
            <div style={{ fontSize:12, color:'var(--text-muted)' }}>{s.label}</div>
          </div>
        ))}
      </div>

      <div className="card">
        <div style={{ overflowX:'auto' }}>
          <table className="data-table">
            <thead>
              <tr><th>Order ID</th><th>Product</th><th>Customer</th><th>Qty</th><th>Total</th><th>Date</th><th>Status</th><th>Transporter</th></tr>
            </thead>
            <tbody>
              {myOrders.map(o => {
                const prod  = DB.products.find(p => p.id === o.productId);
                const cust  = DB.users.find(u => u.id === o.customerId);
                const trans = DB.users.find(u => u.id === o.transportId);
                const ss    = statusStyle(o.status);
                return (
                  <tr key={o.id}>
                    <td style={{ fontWeight:600, color:'var(--green-900)' }}>#ORD-{String(o.id).slice(-4)}</td>
                    <td>{prod?.img} {prod?.name}</td>
                    <td>{cust?.name}</td>
                    <td>{o.qty}</td>
                    <td style={{ fontWeight:600, color:'var(--green-800)' }}>{formatK(o.total)}</td>
                    <td style={{ fontSize:12 }}>{o.date}</td>
                    <td><span className="badge" style={{ background:ss.bg, color:ss.fg }}>{o.status}</span></td>
                    <td style={{ fontSize:12, color:'var(--text-muted)' }}>{trans?.name || '— Unassigned'}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
