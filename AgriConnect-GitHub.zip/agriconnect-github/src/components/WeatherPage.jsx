import { DB } from '../data.js';

export default function WeatherPage() {
  const w = DB.weather;
  const f = DB.forecast;

  const advisories = [
    { icon:'🌧', msg:'Rain expected Thursday & Friday — delay fertilizer top-dressing until soils dry Saturday.', severity:'warning' },
    { icon:'🌱', msg:'Good soil moisture after rains. Ideal window to establish late-season vegetable beds.', severity:'good' },
    { icon:'🦟', msg:'High humidity raises Fall Armyworm risk. Inspect maize fields Wednesday at dawn.', severity:'danger' },
    { icon:'☀️', msg:'Drying period Sunday–Tuesday ideal for groundnut vine turning and drying operations.', severity:'good' },
  ];

  return (
    <div className="fade-up">
      <div className="page-header">
        <h1>Weather & Climate 🌤️</h1>
        <p>Local forecasts and farm-specific weather advisories.</p>
      </div>

      {/* Hero weather card */}
      <div style={{ background:'linear-gradient(135deg,#0d2b1a,#1B4332,#40916C)', borderRadius:20, padding:'28px 32px', marginBottom:20, color:'#fff', position:'relative', overflow:'hidden' }}>
        <div style={{ position:'absolute', right:-40, top:-40, width:200, height:200, borderRadius:'50%', background:'rgba(255,255,255,0.04)' }} />
        <div style={{ position:'absolute', right:40, bottom:-60, width:150, height:150, borderRadius:'50%', background:'rgba(255,255,255,0.03)' }} />
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-end', flexWrap:'wrap', gap:16 }}>
          <div>
            <div style={{ fontSize:11, color:'rgba(255,255,255,0.5)', textTransform:'uppercase', letterSpacing:1, marginBottom:6 }}>📍 {w.location}</div>
            <div style={{ fontSize:76, fontWeight:700, fontFamily:'var(--font-display)', lineHeight:1 }}>{w.temp}<span style={{ fontSize:32 }}>°C</span></div>
            <div style={{ fontSize:20, marginTop:6, opacity:0.85 }}>{w.condition}</div>
          </div>
          <div style={{ display:'flex', gap:12, flexWrap:'wrap' }}>
            {[['💧','Humidity',`${w.humidity}%`],['💨','Wind',w.wind],['🌧','Rain in',w.rainIn]].map(([ic,label,val]) => (
              <div key={label} style={{ background:'rgba(255,255,255,0.1)', borderRadius:12, padding:'12px 18px', backdropFilter:'blur(4px)' }}>
                <div style={{ fontSize:18, marginBottom:4 }}>{ic}</div>
                <div style={{ fontSize:11, opacity:0.6, textTransform:'uppercase', letterSpacing:0.5 }}>{label}</div>
                <div style={{ fontSize:16, fontWeight:700, marginTop:2 }}>{val}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 7-day forecast */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(7,1fr)', gap:10, marginBottom:20 }}>
        {f.map((d,i) => (
          <div key={i} className="card" style={{ textAlign:'center', padding:'14px 8px', background: i===0?'#E8F5E9':'#fff' }}>
            <div style={{ fontSize:11, color:'var(--text-muted)', marginBottom:6, fontWeight:600 }}>{d.day}</div>
            <div style={{ fontSize:28, marginBottom:6 }}>{d.icon}</div>
            <div style={{ fontWeight:700, fontSize:15, color:'var(--green-900)' }}>{d.hi}°</div>
            <div style={{ fontSize:12, color:'var(--text-muted)' }}>{d.lo}°</div>
            <div style={{ fontSize:11, color:'var(--blue-800)', marginTop:5, fontWeight:500 }}>💧{d.rain}%</div>
          </div>
        ))}
      </div>

      {/* Advisories */}
      <div className="card">
        <h3 style={{ fontFamily:'var(--font-display)', fontSize:22, color:'var(--green-900)', marginBottom:14 }}>⚠️ Farming Advisories</h3>
        <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
          {advisories.map((a,i) => {
            const bg = a.severity==='good'?'#E8F5E9':a.severity==='danger'?'#FFEBEE':'#FFF8E1';
            const border = a.severity==='good'?'#C8E6C9':a.severity==='danger'?'#FFCDD2':'#FFE082';
            return (
              <div key={i} style={{ display:'flex', gap:12, padding:'12px 14px', background:bg, borderRadius:10, border:`1px solid ${border}` }}>
                <span style={{ fontSize:18, flexShrink:0 }}>{a.icon}</span>
                <span style={{ fontSize:13.5, color:'var(--text-secondary)', lineHeight:1.6 }}>{a.msg}</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
