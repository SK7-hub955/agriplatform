import { useState } from 'react';
import { DB, formatK, demandColor } from '../data.js';

export default function Marketplace({ user }) {
  const [cart,    setCart]    = useState([]);
  const [search,  setSearch]  = useState('');
  const [cat,     setCat]     = useState('All');
  const [success, setSuccess] = useState(false);
  const [detail,  setDetail]  = useState(null);

  const cats = ['All', ...new Set(DB.products.map(p => p.category))];
  const filtered = DB.products.filter(p =>
    (cat === 'All' || p.category === cat) &&
    p.name.toLowerCase().includes(search.toLowerCase())
  );

  const addToCart = (prod) => {
    setCart(c => {
      const ex = c.find(i => i.id === prod.id);
      return ex ? c.map(i => i.id===prod.id ? {...i, qty:i.qty+1} : i) : [...c, {...prod, qty:1}];
    });
  };
  const removeFromCart = (id) => setCart(c => c.filter(i => i.id !== id));

  const total = cart.reduce((a,b) => a + b.price * b.qty, 0);

  const placeOrder = () => {
    cart.forEach(item => {
      DB.orders.push({
        id: Date.now() + Math.random(),
        customerId: user.id, productId: item.id,
        qty: item.qty, total: item.price * item.qty,
        status: 'Pending', date: new Date().toISOString().split('T')[0], transportId: null,
      });
    });
    setCart([]);
    setSuccess(true);
    setTimeout(() => setSuccess(false), 4000);
  };

  return (
    <div className="fade-up">
      <div className="page-header">
        <h1>Agricultural Marketplace 🛒</h1>
        <p>Browse seeds, fertilizers, and inputs from verified Zambian suppliers.</p>
      </div>

      {success && <div className="alert-success">✅ Order placed successfully! A transporter will be assigned shortly. Check "Recent Orders" on your dashboard.</div>}

      {/* Search & filter bar */}
      <div style={{ display:'flex', gap:12, marginBottom:20, flexWrap:'wrap', alignItems:'center' }}>
        <input type="text" placeholder="🔍  Search products…" value={search} onChange={e=>setSearch(e.target.value)} style={{ flex:'1 1 220px', maxWidth:300 }} />
        <div style={{ display:'flex', gap:6, flexWrap:'wrap' }}>
          {cats.map(c => (
            <button key={c} onClick={() => setCat(c)} style={{
              padding:'8px 16px', borderRadius:99,
              border: `1.5px solid ${cat===c ? 'var(--green-700)' : 'var(--border)'}`,
              background: cat===c ? 'var(--green-700)' : '#fff',
              color: cat===c ? '#fff' : 'var(--text-secondary)',
              cursor:'pointer', fontSize:13, fontFamily:'var(--font-body)', fontWeight:500,
              transition:'all 0.15s',
            }}>{c}</button>
          ))}
        </div>
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'1fr 300px', gap:22, alignItems:'start' }}>
        {/* Products Grid */}
        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(240px,1fr))', gap:16 }}>
          {filtered.map(p => {
            const supplier = DB.users.find(u => u.id === p.supplierId);
            const dc = demandColor(p.demand);
            return (
              <div key={p.id} className="card" style={{ display:'flex', flexDirection:'column', border:'1.5px solid transparent', transition:'border 0.2s, box-shadow 0.2s', cursor:'pointer' }}
                onMouseEnter={e => { e.currentTarget.style.borderColor='#B7E4C7'; e.currentTarget.style.boxShadow='0 6px 24px rgba(27,67,50,0.1)'; }}
                onMouseLeave={e => { e.currentTarget.style.borderColor='transparent'; e.currentTarget.style.boxShadow='var(--shadow-sm)'; }}>
                {/* Image area */}
                <div onClick={() => setDetail(p)} style={{ background:'linear-gradient(135deg,#F0FFF4,#E8F5E9)', borderRadius:10, fontSize:52, display:'flex', alignItems:'center', justifyContent:'center', height:100, marginBottom:14 }}>
                  {p.img}
                </div>

                <div style={{ fontSize:11, color:'var(--text-muted)', marginBottom:3, textTransform:'uppercase', letterSpacing:0.5 }}>{p.category}</div>
                <div style={{ fontWeight:700, fontSize:15, color:'var(--green-900)', marginBottom:2 }}>{p.name}</div>
                <div style={{ fontSize:12, color:'var(--text-muted)', marginBottom:8 }}>by {supplier?.name} {supplier?.verified && '✅'}</div>

                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline', marginBottom:8 }}>
                  <span style={{ fontWeight:700, fontSize:22, color:'var(--green-800)', fontFamily:'var(--font-display)' }}>{formatK(p.price)}</span>
                  <span style={{ fontSize:12, color:'var(--text-muted)' }}>/{p.unit}</span>
                </div>

                {/* AI prediction badge */}
                <div style={{ background:'#FFF8E1', borderRadius:8, padding:'8px 10px', marginBottom:10, fontSize:12 }}>
                  <span style={{ color:'#E65100', fontWeight:600 }}>🤖 AI Forecast: </span>
                  <span style={{ color:'#5D4037' }}>{formatK(p.predictedPrice)} by {p.predictedAvail}. Demand: </span>
                  <span style={{ color:dc.fg, fontWeight:600 }}>{p.demand}</span>
                </div>

                <div style={{ display:'flex', gap:6, marginBottom:12, flexWrap:'wrap' }}>
                  <span className="badge" style={{ background:'#E8F5E9', color:'var(--green-800)' }}>Stock: {p.stock}</span>
                  <span className="badge" style={{ background:'#E3F2FD', color:'var(--blue-800)' }}>{p.season}</span>
                </div>

                <div style={{ marginTop:'auto', display:'flex', gap:8 }}>
                  <button className="btn-outline" style={{ flex:'0 0 auto', padding:'9px 12px', fontSize:13 }} onClick={() => setDetail(p)}>Details</button>
                  <button className="btn-primary" style={{ flex:1 }} onClick={() => addToCart(p)}>Add to Cart</button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Cart */}
        <div className="card" style={{ position:'sticky', top:80 }}>
          <h3 style={{ fontFamily:'var(--font-display)', fontSize:20, color:'var(--green-900)', marginBottom:16 }}>
            🛒 Your Cart <span style={{ fontSize:14, fontWeight:400, color:'var(--text-muted)' }}>({cart.length} item{cart.length!==1?'s':''})</span>
          </h3>
          {cart.length === 0 ? (
            <div style={{ textAlign:'center', color:'var(--text-muted)', padding:'30px 0', fontSize:14 }}>
              <div style={{ fontSize:36, marginBottom:8 }}>🧺</div>
              Your cart is empty.<br/>Browse products and add items.
            </div>
          ) : (
            <>
              <div style={{ display:'flex', flexDirection:'column', gap:2, marginBottom:16 }}>
                {cart.map(item => (
                  <div key={item.id} style={{ display:'flex', justifyContent:'space-between', alignItems:'center', padding:'10px 0', borderBottom:'1px solid #f5f5f5' }}>
                    <div style={{ flex:1 }}>
                      <div style={{ fontSize:13, fontWeight:500 }}>{item.img} {item.name}</div>
                      <div style={{ fontSize:11, color:'var(--text-muted)', marginTop:2 }}>×{item.qty} @ {formatK(item.price)}</div>
                    </div>
                    <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                      <span style={{ fontWeight:700, color:'var(--green-800)', fontSize:14 }}>{formatK(item.price*item.qty)}</span>
                      <button onClick={() => removeFromCart(item.id)} style={{ background:'none', border:'none', cursor:'pointer', color:'#aaa', fontSize:16, padding:'2px 6px' }}>×</button>
                    </div>
                  </div>
                ))}
              </div>

              <div style={{ borderTop:'2px solid var(--green-900)', paddingTop:12, display:'flex', justifyContent:'space-between', marginBottom:16 }}>
                <span style={{ fontWeight:600, fontSize:15 }}>Total</span>
                <span style={{ fontWeight:700, fontSize:20, color:'var(--green-900)', fontFamily:'var(--font-display)' }}>{formatK(total)}</span>
              </div>

              <div style={{ background:'#E3F2FD', borderRadius:8, padding:'10px 12px', marginBottom:14, fontSize:12, color:'var(--blue-800)' }}>
                🚚 Delivery will be assigned automatically. Transport fee calculated at checkout.
              </div>

              <button className="btn-primary" style={{ width:'100%' }} onClick={placeOrder}>
                Place Order & Request Delivery
              </button>
              <button className="btn-ghost" style={{ width:'100%', marginTop:8, textAlign:'center' }} onClick={() => setCart([])}>Clear Cart</button>
            </>
          )}
        </div>
      </div>

      {/* Product Detail Modal */}
      {detail && (
        <div style={{ position:'fixed', inset:0, background:'rgba(0,0,0,0.55)', zIndex:500, display:'flex', alignItems:'center', justifyContent:'center', padding:20 }}
          onClick={() => setDetail(null)}>
          <div style={{ background:'#fff', borderRadius:20, padding:32, maxWidth:520, width:'100%', maxHeight:'90vh', overflowY:'auto' }}
            onClick={e => e.stopPropagation()}>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:20 }}>
              <div>
                <div style={{ fontSize:48 }}>{detail.img}</div>
                <h2 style={{ fontFamily:'var(--font-display)', fontSize:24, color:'var(--green-900)', marginTop:8 }}>{detail.name}</h2>
                <div style={{ fontSize:13, color:'var(--text-muted)', marginTop:2 }}>{detail.category}</div>
              </div>
              <button onClick={() => setDetail(null)} style={{ background:'#f5f5f5', border:'none', borderRadius:8, width:32, height:32, cursor:'pointer', fontSize:18, display:'flex', alignItems:'center', justifyContent:'center' }}>×</button>
            </div>
            <p style={{ fontSize:14, color:'var(--text-secondary)', lineHeight:1.7, marginBottom:20 }}>{detail.description}</p>
            {[['Price', formatK(detail.price)+' / '+detail.unit], ['Stock', detail.stock+' units'], ['Planting Season', detail.season], ['Predicted Price', formatK(detail.predictedPrice)+' ('+detail.predictedAvail+')'], ['Demand Forecast', detail.demand]].map(([k,v]) => (
              <div key={k} style={{ display:'flex', justifyContent:'space-between', padding:'10px 0', borderBottom:'1px solid #f5f5f5', fontSize:14 }}>
                <span style={{ color:'var(--text-muted)' }}>{k}</span>
                <span style={{ fontWeight:600, color:'var(--green-900)' }}>{v}</span>
              </div>
            ))}
            <div style={{ display:'flex', gap:12, marginTop:20 }}>
              <button className="btn-primary" style={{ flex:1 }} onClick={() => { addToCart(detail); setDetail(null); }}>Add to Cart</button>
              <button className="btn-outline" onClick={() => setDetail(null)}>Close</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
