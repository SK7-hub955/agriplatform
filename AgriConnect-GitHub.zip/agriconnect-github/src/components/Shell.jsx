import { DB } from '../data.js';

const NAV = {
  customer:  [['dashboard','📊','Dashboard'],['market','🛒','Marketplace'],['crops','🌾','Crop Guides'],['weather','🌤️','Weather'],['prices','📈','Market Prices'],['community','💬','Community']],
  supplier:  [['dashboard','📊','Dashboard'],['inventory','📦','Inventory'],['orders','📋','Orders'],['prices','📈','Market Prices'],['community','💬','Community']],
  transport: [['dashboard','📊','Dashboard'],['deliveries','🚚','Deliveries'],['earnings','💰','Earnings'],['map','🗺️','Route Map'],['community','💬','Community']],
};

const ROLE_COLOR = { customer:'#40916C', supplier:'#8B6914', transport:'#1565C0' };

export default function Shell({ user, onLogout, children, activeTab, setActiveTab }) {
  const navItems = NAV[user.role] || [];
  const w = DB.weather;

  return (
    <div style={{ display:'flex', flexDirection:'column', minHeight:'100vh', background:'var(--bg)' }}>
      {/* ── Top Bar ── */}
      <header style={{
        background: 'linear-gradient(135deg, #0d2b1a 0%, #1B4332 60%, #2D6A4F 100%)',
        height: 62, display:'flex', alignItems:'center',
        justifyContent:'space-between', padding:'0 24px',
        position:'sticky', top:0, zIndex:200,
        boxShadow:'0 2px 12px rgba(0,0,0,0.25)',
      }}>
        <div style={{ display:'flex', alignItems:'center', gap:10 }}>
          <span style={{ fontSize:26 }}>🌱</span>
          <span style={{ color:'#fff', fontFamily:'var(--font-display)', fontSize:24, fontWeight:700, letterSpacing:'-0.3px' }}>AgriConnect</span>
          <span style={{ color:'rgba(255,255,255,0.3)', fontSize:14, marginLeft:4, display:'none' }}>|</span>
        </div>

        <div style={{ display:'flex', alignItems:'center', gap:14 }}>
          {/* Weather pill */}
          <div style={{ display:'flex', alignItems:'center', gap:8, background:'rgba(255,255,255,0.08)', borderRadius:99, padding:'6px 14px', border:'1px solid rgba(255,255,255,0.1)' }}>
            <span>⛅</span>
            <span style={{ color:'#fff', fontSize:13, fontWeight:500 }}>{w.temp}°C · {w.location.split(',')[0]}</span>
          </div>

          {/* User pill */}
          <div style={{ display:'flex', alignItems:'center', gap:10 }}>
            <div style={{ textAlign:'right' }}>
              <div style={{ color:'#fff', fontSize:13, fontWeight:600, lineHeight:1.3 }}>{user.name}</div>
              <div style={{ color:'rgba(255,255,255,0.5)', fontSize:11, textTransform:'capitalize' }}>
                <span style={{ display:'inline-block', width:7, height:7, borderRadius:'50%', background: ROLE_COLOR[user.role], marginRight:4 }} />
                {user.role} · {user.location}
              </div>
            </div>
            <div style={{
              width:36, height:36, borderRadius:'50%',
              background: ROLE_COLOR[user.role],
              display:'flex', alignItems:'center', justifyContent:'center',
              color:'#fff', fontWeight:700, fontSize:13,
            }}>{user.avatar}</div>
          </div>

          <button onClick={onLogout} style={{
            background:'rgba(255,255,255,0.08)', border:'1px solid rgba(255,255,255,0.15)',
            borderRadius:7, color:'rgba(255,255,255,0.8)', padding:'7px 14px',
            cursor:'pointer', fontSize:12, fontFamily:'var(--font-body)',
            transition:'background 0.2s',
          }}>
            Sign Out
          </button>
        </div>
      </header>

      <div style={{ display:'flex', flex:1 }}>
        {/* ── Sidebar ── */}
        <aside style={{
          width:210, background:'#fff', flexShrink:0,
          borderRight:'1px solid #EAEAEA',
          padding:'18px 10px 24px',
          position:'sticky', top:62, height:'calc(100vh - 62px)',
          overflowY:'auto', display:'flex', flexDirection:'column',
        }}>
          <nav style={{ display:'flex', flexDirection:'column', gap:3 }}>
            {navItems.map(([key, icon, label]) => (
              <button key={key}
                className={`nav-item${activeTab===key?' active':''}`}
                onClick={() => setActiveTab(key)}>
                <span className="nav-icon">{icon}</span>
                <span>{label}</span>
              </button>
            ))}
          </nav>

          {/* Weather mini card */}
          <div style={{
            marginTop:'auto', background:'linear-gradient(135deg,#E8F5E9,#F0FFF4)',
            borderRadius:12, padding:'14px', border:'1px solid #C8E6C9',
          }}>
            <div style={{ fontSize:10, color:'#558B2F', fontWeight:700, textTransform:'uppercase', letterSpacing:0.7, marginBottom:8 }}>Live Weather</div>
            <div style={{ fontSize:28, fontWeight:700, color:'#1B4332', fontFamily:'var(--font-display)', lineHeight:1 }}>{w.temp}°C</div>
            <div style={{ fontSize:12, color:'#555', marginTop:3 }}>{w.condition}</div>
            <div style={{ fontSize:11, color:'#40916C', marginTop:6, display:'flex', gap:8, flexWrap:'wrap' }}>
              <span>💧 {w.humidity}%</span>
              <span>💨 {w.wind}</span>
            </div>
            <div style={{ marginTop:8, padding:'7px 9px', background:'#FFF8E1', borderRadius:7, fontSize:11, color:'#E65100', lineHeight:1.4 }}>
              ⚠️ Rain in {w.rainIn}
            </div>
          </div>
        </aside>

        {/* ── Main ── */}
        <main style={{ flex:1, padding:'28px 30px', overflowY:'auto', minWidth:0 }} className="fade-up">
          {children}
        </main>
      </div>
    </div>
  );
}
