import { useState } from 'react';
import { DB } from '../data.js';

export default function CropGuides() {
  const [selected, setSelected] = useState(null);
  const [search,   setSearch]   = useState('');

  const crops = DB.cropGuides.filter(c => c.name.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="fade-up">
      <div className="page-header">
        <h1>Crop Knowledge Centre 🌾</h1>
        <p>Comprehensive planting guides tailored for Zambian soils and climate.</p>
      </div>

      <input type="text" placeholder="🔍  Search crops…" value={search} onChange={e=>setSearch(e.target.value)} style={{ maxWidth:300, marginBottom:20 }} />

      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(170px,1fr))', gap:14, marginBottom:24 }}>
        {crops.map((c,i) => (
          <div key={i} className="card"
            style={{ cursor:'pointer', textAlign:'center', border:`2px solid ${selected?.name===c.name?'var(--green-600)':'transparent'}`, transition:'all 0.2s' }}
            onClick={() => setSelected(selected?.name===c.name ? null : c)}
            onMouseEnter={e => { if (selected?.name!==c.name) e.currentTarget.style.borderColor='var(--green-200)'; }}
            onMouseLeave={e => { if (selected?.name!==c.name) e.currentTarget.style.borderColor='transparent'; }}>
            <div style={{ fontSize:50, marginBottom:10 }}>{c.img}</div>
            <div style={{ fontFamily:'var(--font-display)', fontSize:18, fontWeight:600, color:'var(--green-900)' }}>{c.name}</div>
            <div style={{ fontSize:11, color:'var(--text-muted)', marginTop:4 }}>Season: {c.season.split(' ')[0]}</div>
          </div>
        ))}
      </div>

      {selected && (
        <div className="card fade-up" style={{ border:'1px solid var(--green-200)' }}>
          <div style={{ display:'flex', alignItems:'center', gap:16, marginBottom:22 }}>
            <span style={{ fontSize:58 }}>{selected.img}</span>
            <div>
              <h2 style={{ fontFamily:'var(--font-display)', fontSize:28, color:'var(--green-900)' }}>{selected.name} — Growing Guide</h2>
              <p style={{ color:'var(--text-muted)', fontSize:13, marginTop:3 }}>Recommended for Zambian farming conditions</p>
            </div>
            <button className="btn-ghost" style={{ marginLeft:'auto' }} onClick={() => setSelected(null)}>✕ Close</button>
          </div>

          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(230px,1fr))', gap:12 }}>
            {[
              ['🌍','Soil Type',         selected.soil],
              ['📅','Planting Season',   selected.season],
              ['📏','Plant Spacing',     selected.spacing],
              ['🧪','Fertilizer',        selected.fertilizer],
              ['🔬','Common Diseases',   selected.diseases],
              ['📊','Expected Yield',    selected.yield],
              ['🌾','Harvest Time',      selected.harvest],
            ].map(([icon,label,val]) => (
              <div key={label} style={{ background:'#F9FBF7', borderRadius:10, padding:'14px 16px' }}>
                <div style={{ fontSize:11, color:'var(--text-muted)', fontWeight:600, textTransform:'uppercase', letterSpacing:0.6, marginBottom:6 }}>{icon} {label}</div>
                <div style={{ fontSize:14, color:'var(--text-primary)', fontWeight:500, lineHeight:1.5 }}>{val}</div>
              </div>
            ))}
          </div>

          {selected.tips && (
            <div style={{ marginTop:16, background:'#E8F5E9', borderRadius:10, padding:'14px 16px', border:'1px solid var(--green-200)' }}>
              <div style={{ fontSize:11, fontWeight:700, color:'var(--green-800)', textTransform:'uppercase', letterSpacing:0.6, marginBottom:6 }}>💡 Expert Tips</div>
              <div style={{ fontSize:13.5, color:'var(--green-900)', lineHeight:1.7 }}>{selected.tips}</div>
            </div>
          )}
        </div>
      )}

      {!selected && (
        <div className="card" style={{ background:'linear-gradient(135deg,#F0FFF4,#E8F5E9)', border:'1px solid var(--green-200)', textAlign:'center', padding:'28px' }}>
          <div style={{ fontSize:32, marginBottom:8 }}>☝️</div>
          <p style={{ color:'var(--text-secondary)', fontSize:14 }}>Click on any crop above to view the full planting guide.</p>
        </div>
      )}
    </div>
  );
}
