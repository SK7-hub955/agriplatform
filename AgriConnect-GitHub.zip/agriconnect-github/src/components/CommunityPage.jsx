import { useState } from 'react';
import { DB } from '../data.js';

const ROLE_BADGE = {
  customer:  { bg:'#E8F5E9', fg:'#2E7D32', label:'Customer' },
  supplier:  { bg:'#FFF3E0', fg:'#E65100', label:'Supplier' },
  transport: { bg:'#E3F2FD', fg:'#1565C0', label:'Transporter' },
  expert:    { bg:'#F3E5F5', fg:'#6A1B9A', label:'Expert' },
};

export default function CommunityPage({ user }) {
  const [posts,   setPosts]   = useState(DB.communityPosts);
  const [newPost, setNewPost] = useState('');
  const [liked,   setLiked]   = useState({});

  const post = () => {
    if (!newPost.trim()) return;
    const p = { id: Date.now(), author: user.name, role: user.role, text: newPost, time: 'Just now', likes: 0, replies: 0 };
    setPosts(prev => [p, ...prev]);
    setNewPost('');
  };

  const like = (id) => {
    if (liked[id]) return;
    setLiked(l => ({...l, [id]:true}));
    setPosts(ps => ps.map(p => p.id===id ? {...p, likes:p.likes+1} : p));
  };

  return (
    <div className="fade-up">
      <div className="page-header">
        <h1>Community & Expert Support 💬</h1>
        <p>Connect with farmers, suppliers, and agronomists across Zambia.</p>
      </div>

      {/* Stats row */}
      <div className="grid-4" style={{ marginBottom:24 }}>
        {[
          { label:'Members', val:'2,847', icon:'👥', bg:'#E8F5E9' },
          { label:'Posts This Month', val:'184', icon:'💬', bg:'#E3F2FD' },
          { label:'Experts Online', val:'3', icon:'🎓', bg:'#FFF3E0' },
          { label:'Active Regions', val:'10', icon:'📍', bg:'#F3E5F5' },
        ].map((s,i) => (
          <div key={i} className="stat-card" style={{ background:s.bg }}>
            <div style={{ fontSize:22, marginBottom:8 }}>{s.icon}</div>
            <div style={{ fontSize:22, fontWeight:700, color:'var(--green-900)', fontFamily:'var(--font-display)' }}>{s.val}</div>
            <div style={{ fontSize:12, color:'var(--text-muted)' }}>{s.label}</div>
          </div>
        ))}
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'1fr 260px', gap:20, alignItems:'start' }}>
        {/* Feed */}
        <div>
          {/* Compose */}
          <div className="card" style={{ marginBottom:16 }}>
            <div style={{ display:'flex', gap:12, alignItems:'flex-start' }}>
              <div style={{ width:38, height:38, borderRadius:'50%', background:'var(--green-700)', display:'flex', alignItems:'center', justifyContent:'center', color:'#fff', fontWeight:700, fontSize:13, flexShrink:0 }}>{user.avatar}</div>
              <textarea
                value={newPost} onChange={e=>setNewPost(e.target.value)}
                placeholder="Share a tip, ask a question, or post an update…"
                rows={3}
                style={{ resize:'vertical', minHeight:80 }}
              />
            </div>
            <div style={{ display:'flex', justifyContent:'flex-end', marginTop:10 }}>
              <button className="btn-primary" onClick={post}>Post to Community</button>
            </div>
          </div>

          {/* Posts */}
          <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
            {posts.map(p => {
              const rb = ROLE_BADGE[p.role] || ROLE_BADGE.customer;
              return (
                <div key={p.id} className="card" style={{ transition:'box-shadow 0.2s' }}
                  onMouseEnter={e => e.currentTarget.style.boxShadow='0 4px 20px rgba(27,67,50,0.10)'}
                  onMouseLeave={e => e.currentTarget.style.boxShadow='var(--shadow-sm)'}>
                  <div style={{ display:'flex', gap:12, alignItems:'flex-start', marginBottom:10 }}>
                    <div style={{
                      width:40, height:40, borderRadius:'50%',
                      background: rb.bg, display:'flex', alignItems:'center', justifyContent:'center',
                      fontWeight:700, fontSize:13, color:rb.fg, flexShrink:0,
                    }}>
                      {p.author.split(' ').map(w=>w[0]).join('').toUpperCase().slice(0,2)}
                    </div>
                    <div style={{ flex:1 }}>
                      <div style={{ display:'flex', gap:8, alignItems:'center', flexWrap:'wrap' }}>
                        <span style={{ fontWeight:600, fontSize:14 }}>{p.author}</span>
                        <span className="badge" style={{ background:rb.bg, color:rb.fg }}>{rb.label}</span>
                        <span style={{ fontSize:11, color:'var(--text-muted)' }}>{p.time}</span>
                      </div>
                    </div>
                  </div>
                  <p style={{ fontSize:14, color:'var(--text-secondary)', lineHeight:1.7, marginBottom:12 }}>{p.text}</p>
                  <div style={{ display:'flex', gap:16 }}>
                    <button onClick={() => like(p.id)} style={{
                      background:'none', border:'none', cursor: liked[p.id]?'default':'pointer',
                      fontSize:12, color: liked[p.id]?'#E53935':'var(--text-muted)',
                      fontFamily:'var(--font-body)', display:'flex', alignItems:'center', gap:4,
                    }}>
                      {liked[p.id]?'❤️':'🤍'} {p.likes} likes
                    </button>
                    <span style={{ fontSize:12, color:'var(--text-muted)' }}>💬 {p.replies} replies</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Sidebar */}
        <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
          <div className="card">
            <h4 style={{ fontFamily:'var(--font-display)', fontSize:18, color:'var(--green-900)', marginBottom:12 }}>🎓 Ask an Expert</h4>
            <p style={{ fontSize:13, color:'var(--text-muted)', marginBottom:12, lineHeight:1.6 }}>Our agronomists are online and ready to help with your farming questions.</p>
            <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
              {[['Dr. Agnes Phiri','Soil & Crop Science','🟢 Online'],['Eng. Bwalya Mwansa','Irrigation & Water','🟢 Online'],['Mrs. Chanda Zulu','Livestock & Poultry','🔴 Away']].map(([name,role,status]) => (
                <div key={name} style={{ display:'flex', gap:10, alignItems:'center', padding:'8px 10px', background:'#F9FBF7', borderRadius:8 }}>
                  <div style={{ width:32, height:32, borderRadius:'50%', background:'var(--green-200)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:13, fontWeight:700, color:'var(--green-900)' }}>
                    {name.split(' ').map(w=>w[0]).join('')}
                  </div>
                  <div style={{ flex:1 }}>
                    <div style={{ fontSize:12, fontWeight:600 }}>{name}</div>
                    <div style={{ fontSize:11, color:'var(--text-muted)' }}>{role}</div>
                  </div>
                  <span style={{ fontSize:10 }}>{status}</span>
                </div>
              ))}
            </div>
            <button className="btn-primary" style={{ width:'100%', marginTop:12, fontSize:13, padding:'9px' }}>Start Live Chat</button>
          </div>

          <div className="card">
            <h4 style={{ fontFamily:'var(--font-display)', fontSize:18, color:'var(--green-900)', marginBottom:12 }}>📍 Regional Groups</h4>
            <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
              {['Lusaka Farmers','Central Province','Eastern Province','Southern Province','Copperbelt Agri'].map((g,i) => (
                <div key={g} style={{ display:'flex', justifyContent:'space-between', padding:'7px 10px', background:'#F9FBF7', borderRadius:7, fontSize:13 }}>
                  <span>{g}</span>
                  <span style={{ color:'var(--text-muted)', fontSize:11 }}>{[247,183,312,156,94][i]} members</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
