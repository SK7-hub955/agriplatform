import { useState } from 'react';
import { DB, formatK, statusStyle } from '../data.js';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

const EARN_DATA = [
  { month:'Nov', earnings:1200 }, { month:'Dec', earnings:1800 },
  { month:'Jan', earnings:2100 }, { month:'Feb', earnings:1600 },
  { month:'Mar', earnings:2400 }, { month:'Apr', earnings:2000 },
  { month:'May', earnings:900  },
];

export function TransportDashboard({ user }) {
  const myDeliveries = DB.deliveries.filter(d => d.transportId === user.id);
  const totalEarnings = myDeliveries.filter(d=>d.status==='Completed').reduce((a,b)=>a+b.fee,0);
  const [accepted, setAccepted] = useState(false);

  return (
    <div className="fade-up">
      <div className="page-header">
        <h1>Transport Dashboard 🚚</h1>
        <p>Manage your deliveries and track your earnings.</p>
      </div>

      {accepted && <div className="alert-success">✅ Delivery accepted! Navigate to Chisamba to collect the order.</div>}

      <div className="grid-4" style={{ marginBottom:24 }}>
        {[
          { label:'Total Deliveries', val:myDeliveries.length,                              icon:'📦', bg:'#E3F2FD' },
          { label:'Total Earned',     val:formatK(totalEarnings),                            icon:'💰', bg:'#E8F5E9' },
          { label:'In Progress',      val:myDeliveries.filter(d=>d.status==='In Progress').length, icon:'🚛', bg:'#FFF8E1' },
          { label:'Rating',           val:'4.9 ★',                                           icon:'⭐', bg:'#FFF3E0' },
        ].map((s,i) => (
          <div key={i} className="stat-card" style={{ background:s.bg }}>
            <div style={{ fontSize:26, marginBottom:10 }}>{s.icon}</div>
            <div style={{ fontSize:24, fontWeight:700, color:'var(--green-900)', fontFamily:'var(--font-display)' }}>{s.val}</div>
            <div style={{ fontSize:12, color:'var(--text-muted)' }}>{s.label}</div>
          </div>
        ))}
      </div>

      <div className="grid-2">
        <div className="card">
          <h3 style={{ fontFamily:'var(--font-display)', fontSize:20, color:'var(--green-900)', marginBottom:16 }}>Recent Deliveries</h3>
          <table className="data-table">
            <thead><tr><th>Delivery</th><th>Route</th><th>Fee</th><th>Status</th></tr></thead>
            <tbody>
              {myDeliveries.map(d => {
                const ss = statusStyle(d.status);
                return (
                  <tr key={d.id}>
                    <td style={{ fontWeight:600 }}>#DEL-{d.id}</td>
                    <td>{d.from} → {d.to}</td>
                    <td style={{ fontWeight:600, color:'var(--green-800)' }}>{formatK(d.fee)}</td>
                    <td><span className="badge" style={{ background:ss.bg, color:ss.fg }}>{d.status}</span></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
          {/* Vehicle Card */}
          <div className="card">
            <h3 style={{ fontFamily:'var(--font-display)', fontSize:18, color:'var(--green-900)', marginBottom:12 }}>🚛 Vehicle Info</h3>
            {[
              ['Truck Type', user.truckType||'3-ton Pickup'],
              ['Plate No',   user.plateNo||'ZMB-4521-T'],
              ['Status',     user.available?'🟢 Available':'🔴 Busy'],
              ['Base',       user.location],
            ].map(([k,v]) => (
              <div key={k} style={{ display:'flex', justifyContent:'space-between', padding:'9px 0', borderBottom:'1px solid #f5f5f5', fontSize:14 }}>
                <span style={{ color:'var(--text-muted)' }}>{k}</span>
                <span style={{ fontWeight:600 }}>{v}</span>
              </div>
            ))}
          </div>

          {/* New request */}
          <div className="card" style={{ background:'#E8F5E9', border:'1px solid var(--green-200)' }}>
            <div style={{ fontWeight:700, color:'var(--green-900)', marginBottom:6 }}>🔔 New Delivery Request</div>
            <div style={{ fontSize:13, color:'var(--text-secondary)', marginBottom:4 }}>📍 Chisamba → Lusaka (110 km)</div>
            <div style={{ fontSize:13, color:'var(--text-secondary)', marginBottom:4 }}>📦 D-Compound Fertilizer × 2 bags</div>
            <div style={{ fontSize:15, fontWeight:700, color:'var(--green-800)', marginBottom:12 }}>Fee: K250</div>
            <div style={{ display:'flex', gap:8 }}>
              <button className="btn-primary" style={{ flex:1, fontSize:13, padding:'9px' }} onClick={() => setAccepted(true)}>Accept</button>
              <button className="btn-outline" style={{ flex:1, fontSize:13, padding:'9px' }}>Decline</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export function TransportDeliveries({ user }) {
  const pending = DB.orders.filter(o => o.status === 'Pending' || !o.transportId);
  const [accepted, setAccepted] = useState({});

  const accept = (orderId) => {
    const o = DB.orders.find(x=>x.id===orderId);
    if (o) { o.transportId = user.id; o.status = 'In Transit'; }
    setAccepted(a => ({...a, [orderId]:true}));
  };

  return (
    <div className="fade-up">
      <div className="page-header">
        <h1>Available Deliveries 🚚</h1>
        <p>Browse and accept new delivery jobs in your area.</p>
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(290px,1fr))', gap:16 }}>
        {pending.map(o => {
          const prod     = DB.products.find(p => p.id === o.productId);
          const customer = DB.users.find(u => u.id === o.customerId);
          const isAccepted = accepted[o.id];
          return (
            <div key={o.id} className="card" style={{ border:`1.5px solid ${isAccepted?'var(--green-400)':'#E3F2FD'}` }}>
              <div style={{ display:'flex', justifyContent:'space-between', marginBottom:12 }}>
                <span style={{ fontWeight:700, color:'var(--green-900)', fontSize:15 }}>Order #{String(o.id).slice(-4)}</span>
                <span className="badge" style={{ background: isAccepted?'#E8F5E9':'#E3F2FD', color: isAccepted?'#2E7D32':'var(--blue-800)' }}>
                  {isAccepted ? '✅ Accepted' : o.status}
                </span>
              </div>
              <div style={{ display:'flex', flexDirection:'column', gap:7, fontSize:13, color:'var(--text-secondary)', marginBottom:14 }}>
                <div>📦 {prod?.img} {prod?.name} × {o.qty}</div>
                <div>👤 {customer?.name} ({customer?.location})</div>
                <div>📍 Pickup: Chisamba → Drop: {customer?.location}</div>
                <div>📅 Ordered: {o.date}</div>
                <div style={{ fontWeight:700, color:'var(--green-800)', fontSize:15, marginTop:4 }}>Fee: K250</div>
              </div>
              {!isAccepted
                ? <button className="btn-primary" style={{ width:'100%' }} onClick={() => accept(o.id)}>Accept Delivery</button>
                : <div style={{ textAlign:'center', color:'var(--green-800)', fontSize:13, fontWeight:600 }}>Navigate to Chisamba to collect ✓</div>
              }
            </div>
          );
        })}
        {pending.length === 0 && (
          <div className="card" style={{ gridColumn:'1/-1', textAlign:'center', padding:'40px', color:'var(--text-muted)' }}>
            <div style={{ fontSize:40, marginBottom:10 }}>🎉</div>
            <div>All deliveries are assigned. Check back soon for new jobs!</div>
          </div>
        )}
      </div>
    </div>
  );
}

export function EarningsPage({ user }) {
  const myDeliveries  = DB.deliveries.filter(d => d.transportId === user.id);
  const totalEarnings = myDeliveries.reduce((a,b)=>a+b.fee,0);
  const completedEarnings = myDeliveries.filter(d=>d.status==='Completed').reduce((a,b)=>a+b.fee,0);

  return (
    <div className="fade-up">
      <div className="page-header">
        <h1>Earnings 💰</h1>
        <p>Track your delivery income and performance over time.</p>
      </div>

      <div className="grid-3" style={{ marginBottom:24 }}>
        {[
          { label:'Total Earned',  val:formatK(completedEarnings), icon:'💰', bg:'#E8F5E9' },
          { label:'This Month',    val:formatK(900),               icon:'📅', bg:'#FFF8E1' },
          { label:'Deliveries Done',val:myDeliveries.filter(d=>d.status==='Completed').length, icon:'✅', bg:'#E3F2FD' },
        ].map((s,i) => (
          <div key={i} className="stat-card" style={{ background:s.bg }}>
            <div style={{ fontSize:30, marginBottom:10 }}>{s.icon}</div>
            <div style={{ fontSize:28, fontWeight:700, color:'var(--green-900)', fontFamily:'var(--font-display)' }}>{s.val}</div>
            <div style={{ fontSize:13, color:'var(--text-muted)' }}>{s.label}</div>
          </div>
        ))}
      </div>

      <div className="grid-2">
        <div className="card">
          <h3 style={{ fontFamily:'var(--font-display)', fontSize:20, color:'var(--green-900)', marginBottom:16 }}>Monthly Earnings (ZMW)</h3>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={EARN_DATA}>
              <XAxis dataKey="month" tick={{ fontSize:11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize:10 }} axisLine={false} tickLine={false} tickFormatter={v=>`K${v}`} width={52} />
              <Tooltip formatter={v=>[`K${v.toLocaleString()}`,'Earnings']} contentStyle={{ borderRadius:10, fontSize:12 }} />
              <Bar dataKey="earnings" fill="#40916C" radius={[5,5,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="card">
          <h3 style={{ fontFamily:'var(--font-display)', fontSize:20, color:'var(--green-900)', marginBottom:16 }}>Delivery History</h3>
          <table className="data-table">
            <thead><tr><th>ID</th><th>Route</th><th>Date</th><th>Fee</th><th>Status</th></tr></thead>
            <tbody>
              {myDeliveries.map(d => {
                const ss = statusStyle(d.status);
                return (
                  <tr key={d.id}>
                    <td style={{ fontWeight:600 }}>#DEL-{d.id}</td>
                    <td style={{ fontSize:12 }}>{d.from} → {d.to}</td>
                    <td style={{ fontSize:12 }}>{d.date}</td>
                    <td style={{ fontWeight:700, color:'var(--green-800)' }}>{formatK(d.fee)}</td>
                    <td><span className="badge" style={{ background:ss.bg, color:ss.fg }}>{d.status}</span></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export function RouteMapPage() {
  return (
    <div className="fade-up">
      <div className="page-header">
        <h1>Route Map 🗺️</h1>
        <p>GPS navigation and live delivery tracking.</p>
      </div>

      {/* Active job banner */}
      <div style={{ background:'linear-gradient(135deg,#1B4332,#2D6A4F)', borderRadius:16, padding:'20px 24px', marginBottom:20, color:'#fff' }}>
        <div style={{ fontSize:11, opacity:0.6, textTransform:'uppercase', letterSpacing:1, marginBottom:8 }}>🟢 Active Delivery</div>
        <div style={{ fontSize:20, fontWeight:700, fontFamily:'var(--font-display)', marginBottom:4 }}>Chisamba → Lusaka</div>
        <div style={{ display:'flex', gap:16, flexWrap:'wrap' }}>
          {[['📦','Cargo','D-Compound Fertilizer ×2'],['📏','Distance','110 km'],['⏱️','ETA','1 h 45 min'],['💰','Fee','K250']].map(([ic,l,v]) => (
            <div key={l} style={{ background:'rgba(255,255,255,0.1)', borderRadius:8, padding:'8px 14px' }}>
              <div style={{ fontSize:10, opacity:0.6 }}>{ic} {l}</div>
              <div style={{ fontSize:13, fontWeight:600, marginTop:2 }}>{v}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Map placeholder */}
      <div className="card" style={{ padding:0, overflow:'hidden', height:400, position:'relative', background:'#E8F5E9' }}>
        {/* Fake map grid */}
        <div style={{ position:'absolute', inset:0, backgroundImage:'repeating-linear-gradient(0deg,#C8E6C9 0,#C8E6C9 1px,transparent 1px,transparent 60px),repeating-linear-gradient(90deg,#C8E6C9 0,#C8E6C9 1px,transparent 1px,transparent 60px)', opacity:0.6 }} />
        <div style={{ position:'absolute', inset:0, display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', gap:12 }}>
          <div style={{ fontSize:56 }}>🗺️</div>
          <div style={{ fontFamily:'var(--font-display)', fontSize:22, color:'var(--green-900)', fontWeight:600 }}>Live Navigation Map</div>
          <div style={{ fontSize:13, color:'var(--text-muted)', maxWidth:380, textAlign:'center', lineHeight:1.6 }}>
            In production, this integrates with the Google Maps or OpenStreetMap API for real-time GPS routing, turn-by-turn navigation, and live delivery tracking.
          </div>
          <div style={{ display:'flex', gap:10, marginTop:4 }}>
            <button className="btn-primary" style={{ fontSize:13 }}>📱 Open in Maps</button>
            <button className="btn-outline" style={{ fontSize:13 }}>🔄 Refresh Location</button>
          </div>
        </div>
        {/* Route dots */}
        {[[20,70],[35,55],[50,48],[65,36],[80,25]].map(([x,y],i) => (
          <div key={i} style={{ position:'absolute', left:`${x}%`, top:`${y}%`, width: i===0||i===4?16:10, height: i===0||i===4?16:10, borderRadius:'50%', background: i===0?'#C62828':i===4?'#2E7D32':'#40916C', border:'2px solid #fff', boxShadow:'0 2px 6px rgba(0,0,0,0.2)', transform:'translate(-50%,-50%)' }} />
        ))}
        <svg style={{ position:'absolute', inset:0, width:'100%', height:'100%', pointerEvents:'none' }}>
          <polyline points="20%,70% 35%,55% 50%,48% 65%,36% 80%,25%" fill="none" stroke="#40916C" strokeWidth="3" strokeDasharray="8,4" opacity="0.7" />
        </svg>
      </div>
    </div>
  );
}
