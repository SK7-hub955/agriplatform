import { useState } from 'react';
import { DB } from '../data.js';

const ROLES = {
  customer:  { label:"Customer",          icon:"🛒", desc:"Buy seeds, fertilizer & produce" },
  supplier:  { label:"Supplier / Producer",icon:"🌾", desc:"List products & manage inventory" },
  transport: { label:"Transporter",        icon:"🚚", desc:"Deliver orders & earn income" },
};

export default function AuthScreen({ onLogin }) {
  const [tab, setTab]         = useState('login');
  const [role, setRole]       = useState('customer');
  const [email, setEmail]     = useState('');
  const [password, setPassword] = useState('');
  const [name, setName]       = useState('');
  const [error, setError]     = useState('');
  const [loading, setLoading] = useState(false);

  const demo = (u) => { setEmail(u.email); setPassword('pass123'); setRole(u.role); setError(''); };

  const handleSubmit = () => {
    setError('');
    if (tab === 'login') {
      setLoading(true);
      setTimeout(() => {
        const user = DB.users.find(u => u.email === email && u.password === password && u.role === role);
        setLoading(false);
        if (user) onLogin(user);
        else setError('Invalid credentials or incorrect role selected.');
      }, 600);
    } else {
      if (!name.trim() || !email.trim() || !password.trim()) { setError('Please fill in all fields.'); return; }
      setLoading(true);
      setTimeout(() => {
        const newUser = {
          id: Date.now(), name, email, password, role,
          avatar: name.split(' ').map(w=>w[0]).join('').toUpperCase().slice(0,2),
          location: 'Zambia', joined: new Date().toLocaleDateString('en-ZM',{month:'short',year:'numeric'}),
          phone: '',
        };
        DB.users.push(newUser);
        setLoading(false);
        onLogin(newUser);
      }, 600);
    }
  };

  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(160deg, #0d2b1a 0%, #1B4332 45%, #40916C 80%, #8B6914 100%)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontFamily: 'var(--font-body)', padding: '20px',
      position: 'relative', overflow: 'hidden',
    }}>
      {/* Decorative circles */}
      <div style={{ position:'absolute', width:500, height:500, borderRadius:'50%', border:'1px solid rgba(255,255,255,0.05)', top:-100, right:-100, pointerEvents:'none' }} />
      <div style={{ position:'absolute', width:300, height:300, borderRadius:'50%', border:'1px solid rgba(255,255,255,0.05)', bottom:-50, left:-50, pointerEvents:'none' }} />

      <div style={{ width:'100%', maxWidth:460, position:'relative', zIndex:1 }}>
        {/* Logo */}
        <div style={{ textAlign:'center', marginBottom:36 }}>
          <div style={{ fontSize:52, marginBottom:10 }}>🌱</div>
          <h1 style={{ color:'#fff', fontSize:38, fontFamily:'var(--font-display)', fontWeight:700, letterSpacing:'-0.5px', marginBottom:6 }}>AgriConnect</h1>
          <p style={{ color:'rgba(255,255,255,0.55)', fontSize:14 }}>Zambia's Agricultural Marketplace Platform</p>
        </div>

        <div style={{
          background: 'rgba(0,0,0,0.38)', backdropFilter:'blur(24px)',
          borderRadius: 20, padding: 32,
          border: '1px solid rgba(255,255,255,0.1)',
        }}>
          {/* Tab toggle */}
          <div style={{ display:'flex', background:'rgba(0,0,0,0.3)', borderRadius:10, padding:4, marginBottom:26 }}>
            {['login','register'].map(t => (
              <button key={t} onClick={() => { setTab(t); setError(''); }}
                style={{
                  flex:1, padding:'10px', border:'none',
                  borderRadius:7,
                  background: tab===t ? 'rgba(64,145,108,0.85)' : 'transparent',
                  color:'#fff', fontFamily:'var(--font-body)', fontWeight:600,
                  cursor:'pointer', fontSize:14, transition:'background 0.2s',
                }}>
                {t === 'login' ? 'Sign In' : 'Create Account'}
              </button>
            ))}
          </div>

          {/* Role selector */}
          <div style={{ marginBottom:20 }}>
            <p style={{ color:'rgba(255,255,255,0.5)', fontSize:11, textTransform:'uppercase', letterSpacing:1, marginBottom:10 }}>I am a…</p>
            <div style={{ display:'flex', gap:8 }}>
              {Object.entries(ROLES).map(([key, cfg]) => (
                <div key={key} onClick={() => setRole(key)}
                  style={{
                    flex:1, padding:'12px 8px',
                    border: `2px solid ${role===key ? '#52B788' : 'rgba(255,255,255,0.12)'}`,
                    borderRadius:10, cursor:'pointer', textAlign:'center',
                    background: role===key ? 'rgba(82,183,136,0.15)' : 'rgba(0,0,0,0.15)',
                    transition:'all 0.2s',
                  }}>
                  <div style={{ fontSize:22, marginBottom:4 }}>{cfg.icon}</div>
                  <div style={{ color:'#fff', fontSize:11, fontWeight:600, lineHeight:1.3 }}>{cfg.label}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Fields */}
          <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
            {tab==='register' && (
              <input
                placeholder="Full name / Business name"
                value={name} onChange={e=>setName(e.target.value)}
                style={{ background:'rgba(255,255,255,0.08)', border:'1px solid rgba(255,255,255,0.2)', color:'#fff' }}
              />
            )}
            <input type="email" placeholder="Email address"
              value={email} onChange={e=>setEmail(e.target.value)}
              style={{ background:'rgba(255,255,255,0.08)', border:'1px solid rgba(255,255,255,0.2)', color:'#fff' }}
            />
            <input type="password" placeholder="Password"
              value={password} onChange={e=>setPassword(e.target.value)}
              onKeyDown={e => e.key==='Enter' && handleSubmit()}
              style={{ background:'rgba(255,255,255,0.08)', border:'1px solid rgba(255,255,255,0.2)', color:'#fff' }}
            />
          </div>

          {error && <p style={{ color:'#FF7043', fontSize:13, marginTop:10, textAlign:'center' }}>{error}</p>}

          <button className="btn-primary" style={{ width:'100%', marginTop:18, padding:'13px', fontSize:15 }}
            onClick={handleSubmit} disabled={loading}>
            {loading ? '⏳ Please wait…' : tab==='login' ? 'Sign In to AgriConnect' : 'Create My Account'}
          </button>

          {/* Demo accounts */}
          <div style={{ marginTop:18, padding:'12px 14px', background:'rgba(255,255,255,0.04)', borderRadius:10, border:'1px solid rgba(255,255,255,0.07)' }}>
            <p style={{ color:'rgba(255,255,255,0.4)', fontSize:11, textAlign:'center', marginBottom:8 }}>
              Demo accounts — click to pre-fill (password: <strong style={{color:'rgba(255,255,255,0.6)'}}>pass123</strong>)
            </p>
            <div style={{ display:'flex', gap:8, justifyContent:'center' }}>
              {DB.users.map(u => (
                <button key={u.id} onClick={() => demo(u)}
                  style={{
                    padding:'6px 14px', background:'rgba(82,183,136,0.15)',
                    border:'1px solid rgba(82,183,136,0.3)', borderRadius:6,
                    color:'#74C69D', fontSize:12, cursor:'pointer',
                    fontFamily:'var(--font-body)', transition:'background 0.2s',
                  }}>
                  {u.avatar} {u.role}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
