import { DB, formatK, statusStyle, trendColor, trendArrow } from '../data.js';

export default function CustomerDashboard({ user }) {
  const myOrders  = DB.orders.filter(o => o.customerId === user.id);
  const activeOrders = myOrders.filter(o => o.status !== 'Delivered').length;
  const totalSpent   = myOrders.reduce((a, b) => a + b.total, 0);

  return (
    <div className="fade-up">
      <div className="page-header">
        <h1>Good day, {user.name.split(' ')[0]} 👋</h1>
        <p>Here's an overview of your farm activity and today's market.</p>
      </div>

      {/* Advisory */}
      <div className="advisory">
        <span className="advisory-icon">⚠️</span>
        <div>
          <div className="advisory-title">Farming Advisory — Lusaka Region</div>
          <div className="advisory-text">{DB.weather.advisory}</div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid-4" style={{ marginBottom:24 }}>
        {[
          { label:'Active Orders',      val:activeOrders,          icon:'📦', bg:'#E3F2FD' },
          { label:'Total Spent',        val:formatK(totalSpent),   icon:'💰', bg:'#F3E5F5' },
          { label:'Orders This Season', val:myOrders.length,       icon:'🛒', bg:'#E8F5E9' },
          { label:'Saved Suppliers',    val:3,                     icon:'⭐', bg:'#FFF3E0' },
        ].map((s,i) => (
          <div key={i} className="stat-card" style={{ background:s.bg }}>
            <div style={{ fontSize:26, marginBottom:10 }}>{s.icon}</div>
            <div style={{ fontSize:26, fontWeight:700, color:'var(--green-900)', fontFamily:'var(--font-display)' }}>{s.val}</div>
            <div style={{ fontSize:12, color:'var(--text-muted)', marginTop:2 }}>{s.label}</div>
          </div>
        ))}
      </div>

      <div className="grid-2">
        {/* Recent Orders */}
        <div className="card">
          <h3 style={{ fontFamily:'var(--font-display)', fontSize:20, color:'var(--green-900)', marginBottom:16 }}>Recent Orders</h3>
          {myOrders.length === 0 ? (
            <p style={{ color:'var(--text-muted)', fontSize:14, textAlign:'center', padding:'20px 0' }}>No orders yet. Visit the Marketplace to get started.</p>
          ) : (
            <table className="data-table">
              <thead><tr><th>Product</th><th>Qty</th><th>Total</th><th>Status</th></tr></thead>
              <tbody>
                {myOrders.map(o => {
                  const prod = DB.products.find(p => p.id === o.productId);
                  const ss   = statusStyle(o.status);
                  return (
                    <tr key={o.id}>
                      <td>{prod?.img} {prod?.name}</td>
                      <td>{o.qty}</td>
                      <td style={{ fontWeight:600, color:'var(--green-800)' }}>{formatK(o.total)}</td>
                      <td><span className="badge" style={{ background:ss.bg, color:ss.fg }}>{o.status}</span></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>

        {/* Market Prices */}
        <div className="card">
          <h3 style={{ fontFamily:'var(--font-display)', fontSize:20, color:'var(--green-900)', marginBottom:16 }}>Today's Market Prices</h3>
          <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
            {DB.marketPrices.slice(0,6).map((m,i) => (
              <div key={i} style={{ display:'flex', justifyContent:'space-between', alignItems:'center', padding:'9px 12px', background:'#F9FBF7', borderRadius:8 }}>
                <span style={{ fontSize:14, fontWeight:500 }}>{m.crop}</span>
                <div style={{ textAlign:'right' }}>
                  <div style={{ fontSize:14, fontWeight:700, color:'var(--green-900)' }}>{m.price}<span style={{ fontSize:11, fontWeight:400, color:'var(--text-muted)' }}>{m.unit}</span></div>
                  <div style={{ fontSize:11, color:trendColor(m.trend), fontWeight:600 }}>{trendArrow(m.trend)} {m.change}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Pest Alerts */}
      <div className="card" style={{ marginTop:20 }}>
        <h3 style={{ fontFamily:'var(--font-display)', fontSize:20, color:'var(--green-900)', marginBottom:14 }}>🔴 Active Pest & Disease Alerts</h3>
        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(280px,1fr))', gap:12 }}>
          {DB.pestAlerts.map((a,i) => (
            <div key={i} style={{ background:a.severity==='High'?'#FFEBEE':'#FFF8E1', borderRadius:10, padding:'14px', border:`1px solid ${a.severity==='High'?'#FFCDD2':'#FFE082'}` }}>
              <div style={{ display:'flex', justifyContent:'space-between', marginBottom:6 }}>
                <span style={{ fontWeight:700, fontSize:14 }}>{a.crop} — {a.pest}</span>
                <span className="badge" style={{ background:a.severity==='High'?'#C62828':'#E65100', color:'#fff' }}>{a.severity}</span>
              </div>
              <div style={{ fontSize:12, color:'#555', marginBottom:4 }}>📍 {a.region}</div>
              <div style={{ fontSize:12, color:'#333' }}>💊 {a.action}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
