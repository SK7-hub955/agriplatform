import { useState } from 'react';
import AuthScreen      from './components/AuthScreen.jsx';
import Shell           from './components/Shell.jsx';
import CustomerDashboard from './components/CustomerDashboard.jsx';
import Marketplace     from './components/Marketplace.jsx';
import CropGuides      from './components/CropGuides.jsx';
import WeatherPage     from './components/WeatherPage.jsx';
import MarketPricesPage from './components/MarketPricesPage.jsx';
import CommunityPage   from './components/CommunityPage.jsx';
import { SupplierDashboard, SupplierInventory, SupplierOrders } from './components/SupplierViews.jsx';
import { TransportDashboard, TransportDeliveries, EarningsPage, RouteMapPage } from './components/TransportViews.jsx';

export default function App() {
  const [user,      setUser]      = useState(null);
  const [activeTab, setActiveTab] = useState('dashboard');

  const handleLogin  = (u) => { setUser(u); setActiveTab('dashboard'); };
  const handleLogout = ()  => { setUser(null); setActiveTab('dashboard'); };

  if (!user) return <AuthScreen onLogin={handleLogin} />;

  const renderPage = () => {
    const t = activeTab;
    if (user.role === 'customer') {
      if (t === 'dashboard') return <CustomerDashboard user={user} />;
      if (t === 'market')    return <Marketplace user={user} />;
      if (t === 'crops')     return <CropGuides />;
      if (t === 'weather')   return <WeatherPage />;
      if (t === 'prices')    return <MarketPricesPage />;
      if (t === 'community') return <CommunityPage user={user} />;
    }
    if (user.role === 'supplier') {
      if (t === 'dashboard') return <SupplierDashboard user={user} />;
      if (t === 'inventory') return <SupplierInventory user={user} />;
      if (t === 'orders')    return <SupplierOrders user={user} />;
      if (t === 'prices')    return <MarketPricesPage />;
      if (t === 'community') return <CommunityPage user={user} />;
    }
    if (user.role === 'transport') {
      if (t === 'dashboard')   return <TransportDashboard user={user} />;
      if (t === 'deliveries')  return <TransportDeliveries user={user} />;
      if (t === 'earnings')    return <EarningsPage user={user} />;
      if (t === 'map')         return <RouteMapPage />;
      if (t === 'community')   return <CommunityPage user={user} />;
    }
    return <div style={{ padding:40, color:'#888' }}>Coming soon…</div>;
  };

  return (
    <Shell user={user} onLogout={handleLogout} activeTab={activeTab} setActiveTab={setActiveTab}>
      {renderPage()}
    </Shell>
  );
}
