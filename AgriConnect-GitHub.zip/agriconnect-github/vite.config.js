import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// IMPORTANT: Set 'base' to your GitHub repo name for GitHub Pages.
// Example: if your repo URL is https://github.com/jane/agriconnect
// then base should be '/agriconnect/'
// If you're deploying to a custom domain or root, set base: '/'

export default defineConfig({
  plugins: [react()],
  base: '/agriconnect/',   // ← Change this to your repo name
  build: {
    outDir: 'dist',
    sourcemap: false,
    rollupOptions: {
      output: {
        manualChunks: {
          react: ['react', 'react-dom'],
          recharts: ['recharts'],
        },
      },
    },
  },
})
