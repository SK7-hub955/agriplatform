# 🌱 AgriConnect

**Zambia's Agricultural Marketplace Platform**

> Connecting Customers, Suppliers/Producers, and Transporters across Zambia's agricultural ecosystem — with AI-powered price predictions, crop guides, weather advisories, and a live marketplace.

[![Deploy to GitHub Pages](https://github.com/YOUR-USERNAME/agriconnect/actions/workflows/deploy.yml/badge.svg)](https://github.com/YOUR-USERNAME/agriconnect/actions/workflows/deploy.yml)
[![React](https://img.shields.io/badge/React-18-61DAFB?logo=react)](https://reactjs.org)
[![Vite](https://img.shields.io/badge/Vite-5-646CFF?logo=vite)](https://vitejs.dev)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

---

## 🔗 Live Demo

> **[https://YOUR-USERNAME.github.io/agriconnect](https://YOUR-USERNAME.github.io/agriconnect)**
>
> *(Replace `YOUR-USERNAME` with your GitHub username after deploying)*

---

## 📸 Features at a Glance

| Role | Key Features |
|------|-------------|
| 🛒 **Customer** | Marketplace with cart, crop planting guides, 7-day weather forecast, live market prices, community forum |
| 🌾 **Supplier** | Inventory management, order tracking, revenue charts, AI demand forecasting |
| 🚚 **Transporter** | Delivery jobs board, earnings tracker, route map, monthly earnings chart |

---

## 🚀 Quick Start

### Run Locally

```bash
# 1. Clone the repository
git clone https://github.com/YOUR-USERNAME/agriconnect.git
cd agriconnect

# 2. Install dependencies
npm install

# 3. Start development server
npm run dev
```

Then open **[http://localhost:5173/agriconnect/](http://localhost:5173/agriconnect/)** in your browser.

### Build for Production

```bash
npm run build      # Outputs to /dist
npm run preview    # Preview the production build locally
```

---

## 🌐 Deploy to GitHub Pages

### Automatic (Recommended)

This repo includes a GitHub Actions workflow that **automatically builds and deploys** every time you push to `main`.

**One-time setup:**

1. Fork or push this repo to GitHub
2. Go to **Settings → Pages**
3. Under **Source**, select **GitHub Actions**
4. Push any change to `main` — the site deploys automatically ✅

**Then update the base URL:**

In `vite.config.js`, change:
```js
base: '/agriconnect/',   // ← must match your exact repo name
```

In `package.json`, change:
```json
"homepage": "https://YOUR-USERNAME.github.io/agriconnect"
```

### Manual Deploy

```bash
npm run build
# Then upload the /dist folder contents to any static host
```

---

## 👤 Demo Accounts

| Role | Email | Password |
|------|-------|----------|
| **Customer** | john@farm.zm | pass123 |
| **Supplier** | gvf@supplier.zm | pass123 |
| **Transporter** | swift@transport.zm | pass123 |

You can also register a new account from the sign-in screen.

---

## 🏗️ Project Structure

```
agriconnect/
├── .github/
│   └── workflows/
│       └── deploy.yml          ← GitHub Actions auto-deploy
├── public/
│   └── favicon.svg
├── src/
│   ├── App.jsx                 ← Root router (role-based page rendering)
│   ├── main.jsx                ← React entry point
│   ├── index.css               ← Global styles & CSS custom properties
│   ├── data.js                 ← Mock database & helper functions
│   └── components/
│       ├── AuthScreen.jsx      ← Login / Register with role selector
│       ├── Shell.jsx           ← Sidebar + topbar layout shell
│       ├── CustomerDashboard.jsx
│       ├── Marketplace.jsx     ← Shopping cart + product detail modal
│       ├── CropGuides.jsx      ← Searchable crop knowledge centre
│       ├── WeatherPage.jsx     ← 7-day forecast + farming advisories
│       ├── MarketPricesPage.jsx ← Recharts bar chart + AI predictions
│       ├── CommunityPage.jsx   ← Forum + expert chat sidebar
│       ├── SupplierViews.jsx   ← Dashboard, Inventory, Orders
│       └── TransportViews.jsx  ← Dashboard, Deliveries, Earnings, Map
├── index.html                  ← Standalone version (no build needed)
├── vite.config.js
├── package.json
├── .gitignore
└── README.md
```

---

## 🛠️ Tech Stack

| Layer | Technology |
|-------|-----------|
| Framework | React 18 |
| Build Tool | Vite 5 |
| Charts | Recharts 2 |
| Fonts | Crimson Pro + DM Sans (Google Fonts) |
| Styling | Pure CSS with CSS custom properties |
| CI/CD | GitHub Actions → GitHub Pages |
| Data | In-memory mock DB (ready to swap with Supabase / Firebase) |

---

## 🔧 Connecting a Real Backend

All mock data lives in `src/data.js`. To connect real APIs:

| Feature | Suggested Service |
|---------|------------------|
| Authentication | [Supabase Auth](https://supabase.com/auth) / Firebase Auth |
| Products & Orders | Supabase / PostgreSQL REST API |
| Weather | [OpenWeatherMap API](https://openweathermap.org/api) |
| Market Prices | ZNFU / ZAMACE commodity feeds |
| Route Map | Google Maps JS API / Leaflet + OpenStreetMap |
| Payments | MTN Mobile Money API / Airtel Money API |

---

## 📄 License

MIT — Free to use and adapt for agricultural development purposes.

---

## 🤝 Contributing

Pull requests are welcome. For major changes, please open an issue first to discuss what you'd like to change.

1. Fork the repo
2. Create a feature branch (`git checkout -b feature/add-livestock-tracker`)
3. Commit changes (`git commit -m 'Add livestock tracker'`)
4. Push to branch (`git push origin feature/add-livestock-tracker`)
5. Open a Pull Request
